package com.website.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebsiteController {
	
	@RequestMapping("/")
	public String index(){
		return "index";
		
	}
	@RequestMapping("/index")
	public String Home(){
		return "index";
		
	}
	
	@RequestMapping("/About")
	public String About(){
		return "About";
		
	}
	
	
	@RequestMapping("/Contact")
	public String Contact(){
		return "contact";
		
	}
	
	@RequestMapping("/Wallet")
	public String Wallet(){
		return "Wallet";
		
	}
	
	@RequestMapping("/Exchange")
	public String Exchange(){
		return "Exchange";
		
	}
	
	@RequestMapping("/Smart")
	public String SmartContract(){
		return "Smart";
		
	}
	
	@RequestMapping("/Blockchain")
	public String Blockchain(){
		return "Blockchain";
		
	}
	@RequestMapping("/Token")
	public String Token(){
		return "Token";
		
	}
	
	
	
	
	
	

}
